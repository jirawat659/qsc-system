using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using QSC.Api.Data;
using QSC.Api.Hubs;
using QSC.Api.Models;
using QSC.Api.Helpers;

namespace QSC.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CapController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;
        private readonly IHubContext<CapChatHub> _hubContext;

        public CapController(AppDbContext context, IWebHostEnvironment env, IHubContext<CapChatHub> hubContext)
        {
            _context = context;
            _env = env;
            _hubContext = hubContext;
        }

        private static bool IsValidImageSignature(byte[] bytes)
        {
            return UploadHelper.IsValidImageSignature(bytes, out _);
        }

        private Task<string> SaveBase64IfPresentAsync(string? input, string subfolder, string prefix, long maxSizeBytes = 10 * 1024 * 1024)
        {
            return UploadHelper.SaveBase64IfPresentAsync(_env, input, subfolder, prefix, maxSizeBytes);
        }

        [HttpGet]
        public async Task<IActionResult> GetCapTasks(
            [FromQuery] int? locationId,
            [FromQuery] int? auditRecordId,
            [FromQuery] int? assignedTo,
            [FromQuery] string? status,
            [FromQuery] int? limit,
            [FromQuery] int? page,
            [FromQuery] int? pageSize)
        {
            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var query = _context.CapTasks
                .AsNoTracking()
                .Include(t => t.Location)
                .Include(t => t.Assignee)
                .Include(t => t.Verifier)
                .Include(t => t.AuditRecord)
                    .ThenInclude(ar => ar!.PrimaryAuditor)
                .Include(t => t.AuditResponse)
                    .ThenInclude(resp => resp!.SurveyItem)
                .Include(t => t.Images)
                .AsQueryable();

            if (role == "AUDITEE")
            {
                if (allowedLocationIds != null)
                {
                    query = query.Where(t => allowedLocationIds.Contains(t.LocationId) || t.AssignedTo == currentUserId);
                }
                else
                {
                    return Ok(new List<object>());
                }
            }
            else if (allowedLocationIds != null)
            {
                query = query.Where(t => allowedLocationIds.Contains(t.LocationId));
            }

            if (locationId.HasValue)
            {
                if (allowedLocationIds != null && !allowedLocationIds.Contains(locationId.Value))
                {
                    return Ok(new List<object>());
                }
                query = query.Where(t => t.LocationId == locationId.Value);
            }
            if (auditRecordId.HasValue) query = query.Where(t => t.AuditRecordId == auditRecordId.Value);
            if (assignedTo.HasValue) query = query.Where(t => t.AssignedTo == assignedTo.Value);
            if (!string.IsNullOrEmpty(status)) query = query.Where(t => t.Status == status);
            if (allowedBrandIds != null)
            {
                query = query.Where(t => t.Location != null && t.Location.LocationBrands.Any(lb => allowedBrandIds.Contains(lb.BrandId)));
            }

            query = query.OrderByDescending(t => t.CreatedAt);

            // 🚀 Pagination support: If page or pageSize is specified, apply pagination
            int totalCount = 0;
            if (page.HasValue || pageSize.HasValue)
            {
                totalCount = await query.CountAsync();
                int currentPage = Math.Max(1, page ?? 1);
                int currentPageSize = Math.Clamp(pageSize ?? 50, 1, 100);
                query = query.Skip((currentPage - 1) * currentPageSize).Take(currentPageSize);
            }
            else if (limit.HasValue)
            {
                query = query.Take(Math.Clamp(limit.Value, 1, 500));
            }
            else
            {
                // Default safety ceiling: prevent pulling excessive historical CAPs in one go
                query = query.Take(300);
            }

            var tasks = await query.ToListAsync();

            var result = tasks.Select(t => new
            {
                id = t.Id,
                auditRecordId = t.AuditRecordId,
                auditResponseId = t.AuditResponseId,
                locationId = t.LocationId,
                locationCode = t.Location?.Code,
                locationName = t.Location?.Name,
                categoryName = t.CategoryName ?? t.AuditResponse?.CategoryName ?? t.AuditResponse?.SurveyItem?.CategoryName ?? "ทั่วไป",
                issueItem = t.IssueItem,
                description = t.Description,
                submissionDeadline = t.SubmissionDeadline,
                status = t.Status,
                assignedTo = t.AssignedTo,
                assigneeName = t.Assignee?.FullName,
                verifiedBy = t.VerifiedBy,
                verifierName = t.Verifier?.FullName,
                auditorName = t.AuditRecord?.PrimaryAuditor?.FullName ?? t.Verifier?.FullName ?? "-",
                auditScore = t.AuditRecord?.PercentageScore,
                questionNumber = t.AuditResponse?.SurveyItem?.OrderIndex,
                afterImages = t.Images.Where(img => img.Phase == "AFTER").Select(img => new
                {
                    id = img.Id,
                    imageUrl = img.ImageUrl,
                    uploadedAt = img.UploadedAt
                }).ToList(),
                completedAt = t.CompletedAt,
                closedAt = t.ClosedAt,
                createdAt = t.CreatedAt
            });

            // 🚀 When paginated (page/pageSize provided), wrap with totalCount so the
            // frontend can drive "load more" correctly.
            if (page.HasValue || pageSize.HasValue)
            {
                return Ok(new
                {
                    items = result,
                    totalCount,
                    page = Math.Max(1, page ?? 1),
                    pageSize = Math.Clamp(pageSize ?? 50, 1, 100)
                });
            }

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCapTaskDetail(int id)
        {
            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks
                .AsNoTracking()
                .AsSplitQuery()
                .Include(t => t.Location)
                .Include(t => t.Assignee)
                .Include(t => t.Verifier)
                .Include(t => t.AuditRecord)
                    .ThenInclude(ar => ar!.PrimaryAuditor)
                .Include(t => t.AuditResponse)
                    .ThenInclude(resp => resp!.SurveyItem)
                .Include(t => t.Images)
                    .ThenInclude(img => img.Uploader)
                        .ThenInclude(u => u!.Role)
                .Include(t => t.Comments)
                    .ThenInclude(c => c.Sender)
                        .ThenInclude(u => u!.Role)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId) && task.AssignedTo != currentUserId)
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk && task.AssignedTo != currentUserId)
                {
                    return Forbid();
                }
            }

            // Fetch BEFORE images directly from AuditResponseImage + CapTaskImages (Phase == BEFORE)
            var beforeImages = new List<string>();
            if (task.AuditResponseId.HasValue)
            {
                beforeImages = await _context.AuditResponseImages
                    .AsNoTracking()
                    .Where(img => img.AuditResponseId == task.AuditResponseId.Value)
                    .Select(img => img.ImageUrl)
                    .ToListAsync();
            }
            var beforeTaskImages = task.Images.Where(img => img.Phase == "BEFORE").Select(img => img.ImageUrl).ToList();
            beforeImages.AddRange(beforeTaskImages);

            return Ok(new
            {
                id = task.Id,
                auditRecordId = task.AuditRecordId,
                auditResponseId = task.AuditResponseId,
                locationId = task.LocationId,
                locationCode = task.Location?.Code,
                locationName = task.Location?.Name,
                issueItem = task.IssueItem,
                description = task.Description,
                submissionDeadline = task.SubmissionDeadline,
                status = task.Status,
                assignedTo = task.AssignedTo,
                assigneeName = task.Assignee?.FullName,
                verifiedBy = task.VerifiedBy,
                verifierName = task.Verifier?.FullName,
                auditorName = task.AuditRecord?.PrimaryAuditor?.FullName ?? task.Verifier?.FullName ?? "-",
                auditScore = task.AuditRecord?.PercentageScore,
                questionNumber = task.AuditResponse?.SurveyItem?.OrderIndex,
                questionText = task.AuditResponse?.SurveyItem?.QuestionText ?? task.IssueItem,
                categoryName = task.CategoryName ?? task.AuditResponse?.SurveyItem?.CategoryName ?? task.AuditResponse?.CategoryName ?? "ทั่วไป",
                scoreGiven = task.AuditResponse?.ScoreGiven,
                fullScore = task.AuditResponse?.SurveyItem?.FullScore ?? 10.0,
                completedAt = task.CompletedAt,
                closedAt = task.ClosedAt,
                createdAt = task.CreatedAt,
                beforeImages = beforeImages,
                afterImages = task.Images.Where(img => img.Phase == "AFTER").Select(img => new
                {
                    id = img.Id,
                    imageUrl = img.ImageUrl,
                    uploadedBy = img.UploadedBy,
                    uploaderName = img.Uploader?.FullName ?? "ผู้ใช้งาน",
                    uploaderRole = img.Uploader?.Role?.Code ?? "STANDARD",
                    uploadedAt = img.UploadedAt
                }).ToList(),
                comments = task.Comments.OrderBy(c => c.CreatedAt).Select(c => new
                {
                    id = c.Id,
                    senderId = c.SenderId,
                    senderName = c.Sender?.FullName ?? "ผู้ใช้งาน",
                    senderRole = c.Sender?.Role?.Code ?? c.SenderRole,
                    message = c.Message,
                    imageUrl = c.ImageUrl,
                    createdAt = c.CreatedAt
                }).ToList(),
                nextAuditNote = task.NextAuditNote,
                followUpStatus = task.FollowUpStatus
            });
        }

        public class CreateManualCapDto
        {
            public int LocationId { get; set; }
            public int? AuditRecordId { get; set; }
            public string? CategoryName { get; set; }
            public string IssueItem { get; set; } = string.Empty;
            public string Description { get; set; } = string.Empty;
            public DateTime? SubmissionDeadline { get; set; }
            public int? AssignedTo { get; set; }
            public List<string>? ImageUrls { get; set; } // Defect / Before images
        }

        [Authorize(Roles = "ADMIN,STANDARD,AUDITOR")]
        [HttpPost]
        public async Task<IActionResult> CreateManualCap([FromBody] CreateManualCapDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.IssueItem))
                return BadRequest(new { message = "กรุณาระบุรายการปัญหา" });
            if (string.IsNullOrWhiteSpace(dto.Description))
                return BadRequest(new { message = "กรุณาระบุรายละเอียดปัญหา" });

            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            if (allowedLocationIds != null && !allowedLocationIds.Contains(dto.LocationId))
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == dto.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk)
                {
                    return Forbid();
                }
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var task = new CapTask
                {
                    LocationId = dto.LocationId,
                    AuditRecordId = dto.AuditRecordId,
                    AuditResponseId = null, // Manual
                    CategoryName = !string.IsNullOrWhiteSpace(dto.CategoryName) ? dto.CategoryName.Trim() : "ทั่วไป",
                    IssueItem = dto.IssueItem.Trim(),
                    Description = dto.Description.Trim(),
                    SubmissionDeadline = dto.SubmissionDeadline ?? DateTime.UtcNow.AddDays(7),
                    Status = "OPEN",
                    AssignedTo = dto.AssignedTo,
                    CreatedAt = DateTime.UtcNow
                };

                _context.CapTasks.Add(task);
                await _context.SaveChangesAsync();

                // Save defect / before images if provided
                if (dto.ImageUrls != null && dto.ImageUrls.Any())
                {
                    foreach (var url in dto.ImageUrls)
                    {
                        if (string.IsNullOrWhiteSpace(url)) continue;
                        var savedUrl = await SaveBase64IfPresentAsync(url, "cap_images", "defect", 10 * 1024 * 1024);
                        if (!string.IsNullOrWhiteSpace(savedUrl))
                        {
                            _context.CapTaskImages.Add(new CapTaskImage
                            {
                                CapTaskId = task.Id,
                                Phase = "BEFORE",
                                ImageUrl = savedUrl,
                                UploadedBy = currentUserId,
                                UploadedAt = DateTime.UtcNow
                            });
                        }
                    }
                    await _context.SaveChangesAsync();
                }

                await transaction.CommitAsync();
                return Ok(task);
            }
            catch (InvalidImageUploadException ex)
            {
                await transaction.RollbackAsync();
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new { message = "เกิดข้อผิดพลาดในการสร้างงานแก้ไข กรุณาลองใหม่อีกครั้ง" });
            }
        }

        public class SubmitRemediationDto
        {
            public string Message { get; set; } = string.Empty;
            public List<string> ImageUrls { get; set; } = new();
        }

        [HttpPost("{id}/submit")]
        public async Task<IActionResult> SubmitRemediation(int id, [FromBody] SubmitRemediationDto dto)
        {
            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId) && task.AssignedTo != currentUserId)
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk && task.AssignedTo != currentUserId)
                {
                    return Forbid();
                }
            }

            if (string.Equals(task.Status, "CLOSED", StringComparison.OrdinalIgnoreCase) || string.Equals(task.Status, "CANCELLED", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new { message = "งานแก้ไขนี้ถูกปิดหรือยกเลิกแล้ว ไม่สามารถส่งข้อมูลเพิ่มเติมได้" });
            }

            // Require at least one evidence image
            if (dto.ImageUrls == null || !dto.ImageUrls.Any(u => !string.IsNullOrWhiteSpace(u)))
            {
                return BadRequest(new { message = "กรุณาแนบรูปภาพหลักฐานหลังการแก้ไขอย่างน้อย 1 รูป เพื่อขออนุมัติ" });
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                task.Status = "SUBMITTED";
                task.CompletedAt = DateTime.UtcNow;

                var user = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == currentUserId);
                var now = DateTime.UtcNow;

                string? firstSavedImageUrl = null;

                // Save AFTER images
                if (dto.ImageUrls != null && dto.ImageUrls.Any())
                {
                    foreach (var url in dto.ImageUrls)
                    {
                        if (string.IsNullOrWhiteSpace(url)) continue;
                        var savedUrl = await SaveBase64IfPresentAsync(url, "cap_images", "cap", 10 * 1024 * 1024);
                        if (!string.IsNullOrWhiteSpace(savedUrl))
                        {
                            if (firstSavedImageUrl == null)
                            {
                                firstSavedImageUrl = savedUrl;
                            }

                            _context.CapTaskImages.Add(new CapTaskImage
                            {
                                CapTaskId = id,
                                Phase = "AFTER",
                                ImageUrl = savedUrl,
                                UploadedBy = currentUserId,
                                UploadedAt = now
                            });
                        }
                    }
                }

                // Add Chat Comment with formatted request note (แจ้งเตือนในแชทโดยไม่เก็บรูปซ้ำ เพราะรูปหลักฐานอยู่ใน CapTaskImages แล้ว)
                var messageText = string.IsNullOrWhiteSpace(dto.Message)
                    ? "📸 [ส่งมอบงานแก้ไข] สาขาได้แนบรูปถ่ายหลักฐานและส่งมอบงานแก้ไขเรียบร้อยแล้ว รอการตรวจสอบ"
                    : $"📸 [ส่งมอบงานแก้ไข] {dto.Message.Trim()}";

                var comment = new CapTaskComment
                {
                    CapTaskId = id,
                    SenderId = currentUserId,
                    SenderRole = role,
                    Message = messageText,
                    ImageUrl = null,
                    CreatedAt = now
                };
                _context.CapTaskComments.Add(comment);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Broadcast via SignalR
                var commentPayload = new
                {
                    id = comment.Id,
                    capTaskId = id,
                    userId = currentUserId,
                    userName = user?.FullName ?? user?.Username ?? "ผู้จัดการสาขา",
                    userRole = user?.Role?.Code ?? role,
                    comment = comment.Message,
                    message = comment.Message,
                    imageUrl = (string?)null,
                    isAuditorComment = false,
                    createdAt = comment.CreatedAt
                };
                await _hubContext.Clients.Group($"cap_{id}").SendAsync("ReceiveCapMessage", commentPayload);

                // Broadcast real-time status update
                await _hubContext.Clients.Group($"cap_{id}").SendAsync("CapStatusUpdated", new
                {
                    capTaskId = id,
                    status = task.Status,
                    updatedBy = user?.FullName ?? user?.Username ?? "ผู้จัดการสาขา",
                    updatedAt = task.CompletedAt
                });

                return Ok(new { message = "ส่งมอบหลักฐานและขออนุมัติการแก้ไขเรียบร้อยแล้ว", status = task.Status });
            }
            catch (InvalidImageUploadException ex)
            {
                await transaction.RollbackAsync();
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new { message = "เกิดข้อผิดพลาดในการส่งหลักฐานการแก้ไข กรุณาลองใหม่อีกครั้ง" });
            }
        }

        public class CloseCapDto
        {
            public string? Note { get; set; }
        }

        [Authorize(Roles = "ADMIN,STANDARD,AUDITOR")]
        [HttpPost("{id}/close")]
        public async Task<IActionResult> CloseCap(int id, [FromBody] CloseCapDto dto)
        {
            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId))
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk)
                {
                    return Forbid();
                }
            }

            var user = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == currentUserId);
            var now = DateTime.UtcNow;

            if (string.Equals(task.Status, "CANCELLED", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new { message = "งานแก้ไขนี้ถูกยกเลิกแล้ว ไม่สามารถปิดงานได้" });
            }

            if (task.Status != "CLOSED")
            {
                task.Status = "CLOSED";
                task.VerifiedBy = currentUserId;
                task.ClosedAt = now;
            }

            if (!string.IsNullOrWhiteSpace(dto.Note))
            {
                var comment = new CapTaskComment
                {
                    CapTaskId = id,
                    SenderId = currentUserId,
                    SenderRole = role,
                    Message = $"[อนุมัติปิดงาน] {dto.Note}",
                    CreatedAt = now
                };
                _context.CapTaskComments.Add(comment);

                var commentPayload = new
                {
                    id = comment.Id,
                    capTaskId = id,
                    userId = currentUserId,
                    userName = user?.FullName ?? user?.Username ?? "ผู้ใช้งาน",
                    userRole = user?.Role?.Code ?? role,
                    comment = comment.Message,
                    message = comment.Message,
                    imageUrl = (string?)null,
                    isAuditorComment = true,
                    createdAt = comment.CreatedAt
                };
                await _hubContext.Clients.Group($"cap_{id}").SendAsync("ReceiveCapMessage", commentPayload);
            }

            await _context.SaveChangesAsync();

            // Broadcast real-time CLOSED status update
            await _hubContext.Clients.Group($"cap_{id}").SendAsync("CapStatusUpdated", new
            {
                capTaskId = id,
                status = "CLOSED",
                note = dto.Note,
                updatedBy = user?.FullName ?? user?.Username ?? "ผู้ตรวจประเมิน",
                updatedAt = task.ClosedAt ?? now
            });

            return Ok(new { message = "อนุมัติและปิดงานแก้ไขสมบูรณ์แล้ว", status = task.Status });
        }

        public class RejectCapDto
        {
            public string Reason { get; set; } = string.Empty;
        }

        [Authorize(Roles = "ADMIN,STANDARD,AUDITOR")]
        [HttpPost("{id}/reject")]
        public async Task<IActionResult> RejectCap(int id, [FromBody] RejectCapDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Reason))
                return BadRequest(new { message = "กรุณาระบุเหตุผลในการปฏิเสธ" });

            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId))
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk)
                {
                    return Forbid();
                }
            }

            if (string.Equals(task.Status, "CLOSED", StringComparison.OrdinalIgnoreCase) || string.Equals(task.Status, "CANCELLED", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new { message = "งานแก้ไขนี้ถูกปิดหรือยกเลิกแล้ว ไม่สามารถส่งกลับแก้ไขได้" });
            }

            task.Status = "REJECTED";
            var now = DateTime.UtcNow;
            var user = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == currentUserId);

            var comment = new CapTaskComment
            {
                CapTaskId = id,
                SenderId = currentUserId,
                SenderRole = role,
                Message = $"[ตีกลับให้แก้ไขใหม่] {dto.Reason}",
                CreatedAt = now
            };
            _context.CapTaskComments.Add(comment);

            await _context.SaveChangesAsync();

            var commentPayload = new
            {
                id = comment.Id,
                capTaskId = id,
                userId = currentUserId,
                userName = user?.FullName ?? user?.Username ?? "ผู้ตรวจประเมิน",
                userRole = user?.Role?.Code ?? role,
                comment = comment.Message,
                message = comment.Message,
                imageUrl = (string?)null,
                isAuditorComment = true,
                createdAt = comment.CreatedAt
            };
            await _hubContext.Clients.Group($"cap_{id}").SendAsync("ReceiveCapMessage", commentPayload);

            await _hubContext.Clients.Group($"cap_{id}").SendAsync("CapStatusUpdated", new
            {
                capTaskId = id,
                status = "REJECTED",
                note = dto.Reason,
                updatedBy = user?.FullName ?? user?.Username ?? "ผู้ตรวจประเมิน",
                updatedAt = now
            });

            return Ok(new { message = "ส่งข้อความตีกลับให้สาขาแก้ไขใหม่แล้ว", status = task.Status });
        }

        public class UpdateStatusDto
        {
            public string Status { get; set; } = string.Empty;
            public string? Note { get; set; }
        }

        [Authorize(Roles = "ADMIN,STANDARD,AUDITOR")]
        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateStatusDto dto)
        {
            var allowedStatuses = new[] { "OPEN", "SUBMITTED", "REJECTED", "CLOSED", "CANCELLED" };
            if (!allowedStatuses.Contains(dto.Status?.ToUpper()))
                return BadRequest(new { message = "สถานะไม่ถูกต้อง" });

            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId))
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk)
                {
                    return Forbid();
                }
            }

            var now = DateTime.UtcNow;
            var user = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == currentUserId);

            var newStatus = dto.Status!.ToUpper();
            task.Status = newStatus;
            if ((newStatus == "CLOSED" || newStatus == "CANCELLED") && !task.ClosedAt.HasValue)
            {
                task.ClosedAt = now;
            }

            if (!string.IsNullOrWhiteSpace(dto.Note))
            {
                var comment = new CapTaskComment
                {
                    CapTaskId = id,
                    SenderId = currentUserId,
                    SenderRole = role,
                    Message = $"[{dto.Status}] {dto.Note}",
                    CreatedAt = now
                };
                _context.CapTaskComments.Add(comment);

                var commentPayload = new
                {
                    id = comment.Id,
                    capTaskId = id,
                    userId = currentUserId,
                    userName = user?.FullName ?? user?.Username ?? "ผู้ใช้งาน",
                    userRole = user?.Role?.Code ?? role,
                    comment = comment.Message,
                    message = comment.Message,
                    imageUrl = (string?)null,
                    isAuditorComment = true,
                    createdAt = comment.CreatedAt
                };
                await _hubContext.Clients.Group($"cap_{id}").SendAsync("ReceiveCapMessage", commentPayload);
            }

            await _context.SaveChangesAsync();

            await _hubContext.Clients.Group($"cap_{id}").SendAsync("CapStatusUpdated", new
            {
                capTaskId = id,
                status = task.Status,
                note = dto.Note,
                updatedBy = user?.FullName ?? user?.Username ?? "ผู้ใช้งาน",
                updatedAt = now
            });

            return Ok(new { message = $"ปรับปรุงสถานะเป็น {task.Status} สำเร็จ", status = task.Status });
        }

        public class PostCommentDto
        {
            public string? Message { get; set; }
            public string? ImageUrl { get; set; }
        }

        [HttpPost("{id}/comments")]
        public async Task<IActionResult> PostComment(int id, [FromBody] PostCommentDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Message) && string.IsNullOrWhiteSpace(dto.ImageUrl))
                return BadRequest(new { message = "กรุณาระบุข้อความหรือแนบรูปภาพ" });

            var (currentUserId, role, allowedLocationIds) = await UserScopeHelper.GetUserScopeAsync(User, _context);
            var (_, _, allowedBrandIds) = await UserScopeHelper.GetUserBrandScopeAsync(User, _context);

            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound();

            if (allowedLocationIds != null && !allowedLocationIds.Contains(task.LocationId) && task.AssignedTo != currentUserId)
            {
                return Forbid();
            }

            if (allowedBrandIds != null)
            {
                bool brandOk = await _context.LocationBrands.AnyAsync(lb => lb.LocationId == task.LocationId && allowedBrandIds.Contains(lb.BrandId));
                if (!brandOk && task.AssignedTo != currentUserId)
                {
                    return Forbid();
                }
            }

            if (string.Equals(task.Status, "CLOSED", StringComparison.OrdinalIgnoreCase)
                || string.Equals(task.Status, "CANCELLED", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new { message = "ไม่สามารถเพิ่มความคิดเห็นในงานที่ปิดหรือยกเลิกแล้วได้" });
            }

            string? processedImageUrl = null;
            if (!string.IsNullOrWhiteSpace(dto.ImageUrl))
            {
                try
                {
                    processedImageUrl = await SaveBase64IfPresentAsync(dto.ImageUrl, "cap_images", "cap", 10 * 1024 * 1024);
                }
                catch (InvalidImageUploadException ex)
                {
                    return BadRequest(new { message = ex.Message });
                }
            }

            var now = DateTime.UtcNow;
            var user = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == currentUserId);

            var comment = new CapTaskComment
            {
                CapTaskId = id,
                SenderId = currentUserId,
                SenderRole = role,
                Message = dto.Message?.Trim() ?? string.Empty,
                ImageUrl = processedImageUrl,
                CreatedAt = now
            };

            _context.CapTaskComments.Add(comment);
            await _context.SaveChangesAsync();

            bool isAuditorComment = string.Equals(role, "AUDITOR", StringComparison.OrdinalIgnoreCase)
                                 || string.Equals(role, "ADMIN", StringComparison.OrdinalIgnoreCase)
                                 || string.Equals(role, "STANDARD", StringComparison.OrdinalIgnoreCase);

            var commentPayload = new
            {
                id = comment.Id,
                capTaskId = id,
                userId = currentUserId,
                userName = user?.FullName ?? user?.Username ?? "ผู้ใช้งาน",
                userRole = user?.Role?.Code ?? role,
                comment = comment.Message,
                message = comment.Message,
                imageUrl = comment.ImageUrl,
                isAuditorComment = isAuditorComment,
                createdAt = comment.CreatedAt
            };
            await _hubContext.Clients.Group($"cap_{id}").SendAsync("ReceiveCapMessage", commentPayload);

            return Ok(comment);
        }

        [HttpPost("upload-image")]
        public async Task<IActionResult> UploadCapImage([FromBody] AuditController.Base64UploadDto dto)
        {
            if (string.IsNullOrEmpty(dto.Base64Data)) return BadRequest(new { message = "กรุณาแนบข้อมูลรูปภาพ" });

            try
            {
                var relativeUrl = await SaveBase64IfPresentAsync(dto.Base64Data, "cap_images", "cap", 10 * 1024 * 1024);
                return Ok(new { url = relativeUrl });
            }
            catch (InvalidImageUploadException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception)
            {
                return StatusCode(500, new { message = "เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ กรุณาลองใหม่อีกครั้ง" });
            }
        }

        public class SaveNextAuditNoteDto
        {
            public string? Note { get; set; }
        }

        [Authorize(Roles = "ADMIN,STANDARD,AUDITOR")]
        [HttpPost("{id}/next-audit-note")]
        public async Task<IActionResult> SaveNextAuditNote(int id, [FromBody] SaveNextAuditNoteDto dto)
        {
            var task = await _context.CapTasks.FindAsync(id);
            if (task == null) return NotFound(new { message = "ไม่พบงาน CAP ที่ระบุ" });

            if (string.IsNullOrWhiteSpace(dto.Note))
            {
                task.NextAuditNote = null;
                task.FollowUpStatus = "NONE";
            }
            else
            {
                task.NextAuditNote = dto.Note?.Trim();
                task.FollowUpStatus = "PENDING";
            }

            await _context.SaveChangesAsync();
            return Ok(new
            {
                message = "บันทึกคำแนะนำสำหรับรอบตรวจถัดไปเรียบร้อยแล้ว",
                nextAuditNote = task.NextAuditNote,
                followUpStatus = task.FollowUpStatus
            });
        }

        [HttpGet("pending-recommendations")]
        public async Task<IActionResult> GetPendingRecommendations([FromQuery] int locationId)
        {
            var recommendations = await _context.CapTasks
                .AsNoTracking()
                .Where(c => c.LocationId == locationId && c.FollowUpStatus == "PENDING" && !string.IsNullOrWhiteSpace(c.NextAuditNote))
                .OrderByDescending(c => c.CreatedAt)
                .Select(c => new
                {
                    id = c.Id,
                    issueItem = c.IssueItem,
                    description = c.Description,
                    nextAuditNote = c.NextAuditNote,
                    createdAt = c.CreatedAt
                })
                .ToListAsync();

            return Ok(recommendations);
        }
    }
}